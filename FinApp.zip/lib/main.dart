import 'package:flutter/material.dart';
import 'package:flutterapp/finappapp/generatedhomepgwidget/GeneratedHomePgWidget.dart';
import 'package:flutterapp/finappapp/generatedsignuppgwidget/GeneratedSignUpPgWidget.dart';
import 'package:flutterapp/finappapp/generatedsigninpgwidget/GeneratedSignInPgWidget.dart';
import 'package:flutterapp/finappapp/generatedforgetpasspgwidget/GeneratedForgetPassPgWidget.dart';
import 'package:flutterapp/finappapp/generatedforgetpass2pgwidget/GeneratedForgetPass2PgWidget.dart';
import 'package:flutterapp/finappapp/generatededitbudgetpgwidget/GeneratedEditBudgetPgWidget.dart';
import 'package:flutterapp/finappapp/generatedexpensespgwidget/GeneratedExpensesPgWidget.dart';
import 'package:flutterapp/finappapp/generatedbudgetpgwidget/GeneratedBudgetPgWidget.dart';
import 'package:flutterapp/finappapp/generatedaddincomepgwidget/GeneratedAddIncomePgWidget.dart';
import 'package:flutterapp/finappapp/generatedsavedincomepgwidget/GeneratedSavedIncomePgWidget.dart';
import 'package:flutterapp/finappapp/generatedsavedpaymentpgwidget/GeneratedSavedPaymentPgWidget.dart';
import 'package:flutterapp/finappapp/generatedsavedbudgetpgwidget/GeneratedSavedBudgetPgWidget.dart';
import 'package:flutterapp/finappapp/generatedsavedexpensepgwidget/GeneratedSavedExpensePgWidget.dart';
import 'package:flutterapp/finappapp/generatedsavedsavingspgwidget/GeneratedSavedSavingsPgWidget.dart';
import 'package:flutterapp/finappapp/generatednewpaymentpgwidget/GeneratedNewPaymentPgWidget.dart';
import 'package:flutterapp/finappapp/generatedsetbudgetpgwidget/GeneratedSetBudgetPgWidget.dart';
import 'package:flutterapp/finappapp/generatedsetsavingspgwidget/GeneratedSetSavingsPgWidget.dart';
import 'package:flutterapp/finappapp/generatedaddexpense2pgwidget/GeneratedAddExpense2PgWidget.dart';
import 'package:flutterapp/finappapp/generatedaddexpensepgwidget/GeneratedAddExpensePgWidget.dart';
import 'package:flutterapp/finappapp/generatedsavingspgwidget/GeneratedSavingsPgWidget.dart';
import 'package:flutterapp/finappapp/generatedincomepgwidget/GeneratedIncomePgWidget.dart';
import 'package:flutterapp/finappapp/generatedsettingspgwidget/GeneratedSettingsPgWidget.dart';
import 'package:flutterapp/finappapp/generatedincomehistorypgwidget/GeneratedIncomeHistoryPgWidget.dart';
import 'package:flutterapp/finappapp/generatedupcomingpaymentspgwidget/GeneratedUpcomingPaymentsPgWidget.dart';
import 'package:flutterapp/finappapp/generatedgroup1widget/GeneratedGroup1Widget.dart';
import 'package:flutterapp/finappapp/generatedexpensehistorypgwidget/GeneratedExpenseHistoryPgWidget.dart';
import 'package:flutterapp/finappapp/generatedincomegraphpgwidget/GeneratedIncomeGraphPgWidget.dart';
import 'package:flutterapp/finappapp/generatedexpensesgraphpgwidget/GeneratedExpensesGraphPgWidget.dart';
import 'package:flutterapp/finappapp/generatedsavingsgraphpgwidget/GeneratedSavingsGraphPgWidget.dart';

void main() {
  runApp(FinAppApp());
}

class FinAppApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/GeneratedHomePgWidget',
      routes: {
        '/GeneratedHomePgWidget': (context) => GeneratedHomePgWidget(),
        '/GeneratedSignUpPgWidget': (context) => GeneratedSignUpPgWidget(),
        '/GeneratedSignInPgWidget': (context) => GeneratedSignInPgWidget(),
        '/GeneratedForgetPassPgWidget': (context) =>
            GeneratedForgetPassPgWidget(),
        '/GeneratedForgetPass2PgWidget': (context) =>
            GeneratedForgetPass2PgWidget(),
        '/GeneratedEditBudgetPgWidget': (context) =>
            GeneratedEditBudgetPgWidget(),
        '/GeneratedExpensesPgWidget': (context) => GeneratedExpensesPgWidget(),
        '/GeneratedBudgetPgWidget': (context) => GeneratedBudgetPgWidget(),
        '/GeneratedAddIncomePgWidget': (context) =>
            GeneratedAddIncomePgWidget(),
        '/GeneratedSavedIncomePgWidget': (context) =>
            GeneratedSavedIncomePgWidget(),
        '/GeneratedSavedPaymentPgWidget': (context) =>
            GeneratedSavedPaymentPgWidget(),
        '/GeneratedSavedBudgetPgWidget': (context) =>
            GeneratedSavedBudgetPgWidget(),
        '/GeneratedSavedExpensePgWidget': (context) =>
            GeneratedSavedExpensePgWidget(),
        '/GeneratedSavedSavingsPgWidget': (context) =>
            GeneratedSavedSavingsPgWidget(),
        '/GeneratedNewPaymentPgWidget': (context) =>
            GeneratedNewPaymentPgWidget(),
        '/GeneratedSetBudgetPgWidget': (context) =>
            GeneratedSetBudgetPgWidget(),
        '/GeneratedSetSavingsPgWidget': (context) =>
            GeneratedSetSavingsPgWidget(),
        '/GeneratedAddExpense2PgWidget': (context) =>
            GeneratedAddExpense2PgWidget(),
        '/GeneratedAddExpensePgWidget': (context) =>
            GeneratedAddExpensePgWidget(),
        '/GeneratedSavingsPgWidget': (context) => GeneratedSavingsPgWidget(),
        '/GeneratedIncomePgWidget': (context) => GeneratedIncomePgWidget(),
        '/GeneratedSettingsPgWidget': (context) => GeneratedSettingsPgWidget(),
        '/GeneratedIncomeHistoryPgWidget': (context) =>
            GeneratedIncomeHistoryPgWidget(),
        '/GeneratedUpcomingPaymentsPgWidget': (context) =>
            GeneratedUpcomingPaymentsPgWidget(),
        '/GeneratedGroup1Widget': (context) => GeneratedGroup1Widget(),
        '/GeneratedExpenseHistoryPgWidget': (context) =>
            GeneratedExpenseHistoryPgWidget(),
        '/GeneratedIncomeGraphPgWidget': (context) =>
            GeneratedIncomeGraphPgWidget(),
        '/GeneratedExpensesGraphPgWidget': (context) =>
            GeneratedExpensesGraphPgWidget(),
        '/GeneratedSavingsGraphPgWidget': (context) =>
            GeneratedSavingsGraphPgWidget(),
      },
    );
  }
}
